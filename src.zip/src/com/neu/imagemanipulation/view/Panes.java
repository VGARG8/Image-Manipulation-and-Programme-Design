package com.neu.imagemanipulation.view;

import javax.swing.*;


public class Panes extends JPanel {


  public Panes(Boolean visibility) {
    super();
    setVisible(visibility);
  }
}
