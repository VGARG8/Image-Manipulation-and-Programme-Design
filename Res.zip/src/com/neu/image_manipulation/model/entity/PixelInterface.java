package com.neu.image_manipulation.model.entity;

public interface PixelInterface {
  int getRed();

  int getBlue();

  int getGreen();
}
